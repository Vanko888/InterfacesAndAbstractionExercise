﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Exceptions
{
    public class ExceptionMessages
    {
        public static string InvalidNumber = "Invalid number!";
        public static string InvalidUrl = "Invalid URL!";
    }
}
